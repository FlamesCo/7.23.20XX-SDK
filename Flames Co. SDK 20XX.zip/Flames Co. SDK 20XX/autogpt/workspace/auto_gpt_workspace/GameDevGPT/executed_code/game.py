import pygame

# Initialize Pygame
pygame.init()

# Set the dimensions of the game window
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))

# Create the main character
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((50, 50))
        self.image.fill((255, 255, 255))
        self.rect = self.image.get_rect()

player = Player()

# Implement basic controls
def handle_events():
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                player.rect.x -= 5
            elif event.key == pygame.K_RIGHT:
                player.rect.x += 5
            elif event.key == pygame.K_UP:
                player.rect.y -= 5
            elif event.key == pygame.K_DOWN:
                player.rect.y += 5

# Game loop
while True:
    handle_events()
    screen.fill((0, 0, 0))
    screen.blit(player.image, player.rect)
    pygame.display.update()