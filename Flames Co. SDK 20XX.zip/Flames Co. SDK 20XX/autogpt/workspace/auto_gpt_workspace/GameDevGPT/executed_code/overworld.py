class Overworld:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.tiles = [[None for _ in range(height)] for _ in range(width)]

    def generate(self):
        for x in range(self.width):
            for y in range(self.height):
                self.tiles[x][y] = Tile()

class Tile:
    def __init__(self):
        self.occupied = False