import os
os.makedirs('AutoGPT/plugins', exist_ok=True)