import os
os.getcwd()