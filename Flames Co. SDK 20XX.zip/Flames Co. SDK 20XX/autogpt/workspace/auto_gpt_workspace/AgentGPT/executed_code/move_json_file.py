import shutil
shutil.move('auto-gpt-memory.json', 'AutoGPT/plugins/auto-gpt-memory.json')