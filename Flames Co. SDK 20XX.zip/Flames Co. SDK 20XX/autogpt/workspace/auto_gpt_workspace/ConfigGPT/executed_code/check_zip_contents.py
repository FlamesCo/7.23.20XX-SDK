import zipfile

zip_files = ['plugins/dummy1.zip', 'plugins/dummy2.zip']

for zip_file in zip_files:
    with zipfile.ZipFile(zip_file, 'r') as zip_ref:
        print(zip_ref.namelist())