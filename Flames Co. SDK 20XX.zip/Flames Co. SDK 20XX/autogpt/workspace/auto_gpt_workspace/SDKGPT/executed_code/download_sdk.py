import requests

url = 'https://github.com/FlamesCoLTDRobotics/FlamesSDKV0'
response = requests.get(url)

with open('FlamesSDKV0.zip', 'wb') as f:
    f.write(response.content)