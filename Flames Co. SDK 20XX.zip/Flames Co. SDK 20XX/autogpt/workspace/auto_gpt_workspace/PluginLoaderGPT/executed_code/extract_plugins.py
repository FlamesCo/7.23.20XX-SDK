import zipfile
with zipfile.ZipFile('plugins/dummy1.zip', 'r') as zip_ref:
    zip_ref.extractall('correct_folder')
with zipfile.ZipFile('plugins/dummy2.zip', 'r') as zip_ref:
    zip_ref.extractall('correct_folder')