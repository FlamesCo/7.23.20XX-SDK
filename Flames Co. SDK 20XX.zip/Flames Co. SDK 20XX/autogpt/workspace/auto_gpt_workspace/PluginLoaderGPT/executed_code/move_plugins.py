import shutil
shutil.move('plugins/dummy1.zip', 'correct_folder/dummy1.zip')
shutil.move('plugins/dummy2.zip', 'correct_folder/dummy2.zip')