import os
os.makedirs('correct_folder', exist_ok=True)